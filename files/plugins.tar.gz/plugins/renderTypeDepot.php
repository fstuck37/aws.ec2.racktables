<?php
// Custom Racktables Depot View by Type v.0.0.1
// 2016-11-11 - Fred Stuck fred@geek37.com

function renderTypeDepot ()
{
        global $pageno, $nextorder;
        $cellfilter = getCellFilter();        
        $objects = array();
        $objects_count = getEntitiesCount ('object');
        $showobjecttype = (getConfigVar ('SHOW_OBJECTTYPE') == 'yes');
	$showtypegroups = (getConfigVar ('group_depot_by_type') == 'yes');
//	$showtypegroups = false;

	if ($showtypegroups)
	{
		echo "<table border=0 class=objectview>\n";
		echo "<tr><td class=pcleft>";

		if ($objects_count == 0)
			echo '<h2>No objects exist</h2>';
		// 1st attempt: do not fetch all objects if cellfilter is empty and rendering empty result is enabled
		elseif (! ($cellfilter['is_empty'] && renderEmptyResults ($cellfilter, 'objects', $objects_count)))
		{                
			$objects = applyCellFilter ('object', $cellfilter);
			// 2nd attempt: do not render all fetched objects if rendering empty result is enabled
			if (! renderEmptyResults ($cellfilter, 'objects', count($objects)))
			{
				startPortlet ('Object Type (' . count ($objects) . ')');
				echo '<br><br><table border=0 cellpadding=5 cellspacing=0 align=center class=cooltable>';

				echo '<th>Type ID</th>';
				echo '<th>Type</th>';				
				$order = 'odd';
				# gather IDs of all objects and fetch rackspace info in one pass
				$typelisttmp = array();
				foreach ($objects as $obj)
					$typelisttmp[] = decodeObjectType ($obj['objtype_id']);
				$typelist = array();					
				$typelist = array_unique($typelisttmp);
				
				foreach ($typelist as $obj)
				{
					echo "<tr class='row_${order} tdleft ${problem}' valign=top><td>" . mkA ("<strong>${obj['dname']}</strong>", 'depot',$obj['dname']);
					echo "<td>" . $obj . "</td>";
					echo '</tr>';
				}
				echo '</table>';
				finishPortlet();
			}
		}

		echo "</td><td class=pcright width='25%'>";

		renderCellFilterPortlet ($cellfilter, 'object', $objects);
		echo "</td></tr></table>\n";
	} else {
		renderDepot ();
	}
}

